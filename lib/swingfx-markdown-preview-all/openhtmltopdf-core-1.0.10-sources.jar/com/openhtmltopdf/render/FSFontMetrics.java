/*
 * {{{ header & license
 * Copyright (c) 2006 Wisconsin Court System
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * }}}
 */
package com.openhtmltopdf.render;

public interface FSFontMetrics {
    public float getAscent();
    
    /**
     * In keeping with the JDK {@link java.awt.font.LineMetrics} convention, this number is
     * positive for values below the baseline.
     */
    public float getDescent();
    public float getStrikethroughOffset();
    public float getStrikethroughThickness();
    
    /**
     * In keeping with the JDK {@link java.awt.font.LineMetrics} convention, this number is
     * positive for values below the baseline.
     */
    public float getUnderlineOffset();
    
    public float getUnderlineThickness();
}
